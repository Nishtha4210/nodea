const express = require("express");
const router = express.Router();
const productController = require("../controllers/productController");
const { requireAuth } = require("../middleware/auth");

// Public-ish (but still requires login) — view all products, with category filter
router.get("/", requireAuth, productController.listAllProducts);

// Must come BEFORE /:id routes so "mine" and "new" aren't treated as an :id
router.get("/mine", requireAuth, productController.listMyProducts);
router.get("/new", requireAuth, productController.newProductForm);
router.post("/", requireAuth, productController.createProduct);

router.get("/:id", requireAuth, productController.getProduct);
router.get("/:id/edit", requireAuth, productController.editProductForm);
router.put("/:id", requireAuth, productController.updateProduct);
router.delete("/:id", requireAuth, productController.deleteProduct);

module.exports = router;
