const express = require("express");
const router = express.Router();
const categoryController = require("../controllers/categoryController");
const { requireAuth, requireRole } = require("../middleware/auth");

// Any logged-in user can view categories
router.get("/", requireAuth, categoryController.listCategories);

// Only admins can create/update/delete categories
router.get("/new", requireAuth, requireRole("admin"), categoryController.newCategoryForm);
router.post("/", requireAuth, requireRole("admin"), categoryController.createCategory);
router.get("/:id/edit", requireAuth, requireRole("admin"), categoryController.editCategoryForm);
router.put("/:id", requireAuth, requireRole("admin"), categoryController.updateCategory);
router.delete("/:id", requireAuth, requireRole("admin"), categoryController.deleteCategory);

module.exports = router;
