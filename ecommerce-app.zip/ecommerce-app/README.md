# ShopMVC — E-commerce Platform (Node.js Practical Exam)

A full MVC e-commerce app built with **Express + EJS + MongoDB (Mongoose)**,
using **JWT stored in an HTTP-only cookie** for auth, **role-based access
control** (`admin` / `user`), multi-user product ownership, category
management, and a responsive navbar.

---

## 1. Folder structure (MVC)

```
ecommerce-app/
├── server.js                 # App entry point — wires everything together
├── package.json
├── .env.example               # copy to .env and fill in your values
├── config/
│   └── db.js                  # MongoDB connection
├── models/                    # M — Mongoose schemas
│   ├── User.js
│   ├── Product.js
│   └── Category.js
├── controllers/               # C — business logic
│   ├── authController.js
│   ├── productController.js
│   └── categoryController.js
├── middleware/
│   └── auth.js                # verifyToken / requireAuth / requireRole
├── routes/                    # maps URLs -> controllers
│   ├── authRoutes.js
│   ├── productRoutes.js
│   └── categoryRoutes.js
├── views/                     # V — EJS templates
│   ├── partials/
│   │   ├── head.ejs
│   │   └── navbar.ejs
│   ├── login.ejs
│   ├── register.ejs
│   ├── productList.ejs
│   ├── myProducts.ejs
│   ├── productForm.ejs
│   ├── productItem.ejs
│   ├── categoryList.ejs
│   ├── categoryForm.ejs
│   └── error.ejs
└── public/
    └── css/
        └── style.css           # all styling — responsive, no framework needed
```

---

## 2. Setup — step by step

### Step 1 — Install prerequisites on your machine
- **Node.js** (v18+) — [nodejs.org](https://nodejs.org)
- **MongoDB Community Server** running locally, OR a free **MongoDB Atlas** cluster.

### Step 2 — Get the project onto your computer
Unzip the project folder anywhere, e.g. `Desktop/ecommerce-app`.

### Step 3 — Install dependencies
Open a terminal **inside the `ecommerce-app` folder** and run:
```bash
npm install
```
This reads `package.json` and downloads `express`, `mongoose`, `ejs`,
`jsonwebtoken`, `cookie-parser`, `bcryptjs`, `method-override`, `dotenv`, `body-parser`.

### Step 4 — Configure environment variables
Duplicate `.env.example` and rename the copy to **`.env`** (same folder as `server.js`).
Open `.env` and set:
```
MONGO_URI=mongodb://127.0.0.1:27017/ecommerce_mvc
JWT_SECRET=any_long_random_string_here
PORT=3000
```
If you're using MongoDB Atlas instead of a local DB, paste your Atlas
connection string as `MONGO_URI` (Atlas dashboard → Connect → Drivers).

### Step 5 — Run the app
```bash
npm start
```
or, for auto-restart while you edit files:
```bash
npm run dev
```
You should see:
```
✅ MongoDB Connected: ...
🚀 Server running at http://localhost:3000
```

### Step 6 — Use it
Open **http://localhost:3000** in your browser.
1. Click **Register** → create an **admin** account first (choose "Admin" in
   the Account Type dropdown) — only admins can create categories.
2. Log in, go to **Categories → + Add Category**, add a few (e.g. Electronics, Clothing, Books).
3. Register a second, normal **user** account (or just add products with your admin account too).
4. Go to **+ Add Product** to list products — each product is tied to whoever is logged in.
5. **All Products** shows everyone's listings (filterable by category).
   **My Products** shows only the logged-in user's own listings, with Edit/Delete.

---

## 3. Where each exam requirement lives

| Requirement | File(s) |
|---|---|
| Project setup, dependencies, Express server | `package.json`, `server.js` |
| MongoDB models (Product, Category, User) | `models/*.js` |
| User model with roles + hashed passwords | `models/User.js` (bcrypt hook + `comparePassword`) |
| Register/Login controllers, JWT issued as cookie, role in payload | `controllers/authController.js` |
| `cookie-parser` setup, logout clears cookie | `server.js`, `authController.js` (`logout`) |
| JWT verification middleware, attach user to request, protect routes | `middleware/auth.js` |
| Role-based route protection | `routes/categoryRoutes.js` (`requireRole("admin")`) |
| Multi-user products, "my products" | `models/User.js` (`products` array), `productController.js` (`listMyProducts`), `views/myProducts.ejs` |
| Category CRUD + product filtering by category | `controllers/categoryController.js`, `productController.js` (`listAllProducts` with `?category=`) |
| Populate (category name & owner username on products) | `productController.js` (`.populate("category")`, `.populate("user", "username")`) |
| All required views | `views/*.ejs` |
| Responsive navbar with role-aware links | `views/partials/navbar.ejs`, `public/css/style.css` |

---

## 4. Notes for the examiner
- Passwords are hashed with **bcryptjs** before saving (never stored in plain text).
- The JWT is stored in an **httpOnly cookie** named `token` — not accessible
  from client-side JavaScript, which protects against XSS token theft.
- `method-override` lets HTML `<form>` tags submit `PUT`/`DELETE` requests
  (browsers only natively support GET/POST in forms).
- Ownership checks: a normal `user` can only edit/delete **their own**
  products; an `admin` can edit/delete **any** product and manage categories.
