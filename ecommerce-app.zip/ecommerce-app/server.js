require("dotenv").config();
const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const methodOverride = require("method-override");

const connectDB = require("./config/db");
const { verifyToken } = require("./middleware/auth");

const authRoutes = require("./routes/authRoutes");
const productRoutes = require("./routes/productRoutes");
const categoryRoutes = require("./routes/categoryRoutes");

const app = express();

// ---------- Database ----------
connectDB();

// ---------- View engine ----------
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// ---------- Core middleware ----------
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cookieParser());
// Lets HTML forms send ?_method=PUT / ?_method=DELETE since <form> only supports GET/POST
app.use(methodOverride("_method"));
app.use(express.static(path.join(__dirname, "public")));

// Attach req.user / res.locals.user (if a valid JWT cookie is present) on every request
app.use(verifyToken);

// Makes the current URL path available in every view (used to highlight the active navbar link)
app.use((req, res, next) => {
  res.locals.currentPath = req.path;
  next();
});

// ---------- Routes ----------
app.get("/", (req, res) => res.redirect("/products"));

app.use("/", authRoutes); // /login, /register, /logout
app.use("/products", productRoutes);
app.use("/categories", categoryRoutes);

// ---------- 404 ----------
app.use((req, res) => {
  res.status(404).render("error", {
    title: "Page Not Found",
    message: "The page you're looking for doesn't exist.",
  });
});

// ---------- Start server ----------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
