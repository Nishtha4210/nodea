const jwt = require("jsonwebtoken");

/**
 * verifyToken
 * Reads the JWT from the "token" cookie (if present), verifies it,
 * and attaches the decoded payload to req.user (and res.locals.user
 * so every EJS view can read it, e.g. to show/hide navbar links).
 * This never blocks the request — it just tells us WHO is asking.
 * Use `requireAuth` / `requireRole` afterwards to actually protect routes.
 */
const verifyToken = (req, res, next) => {
  const token = req.cookies.token;

  if (!token) {
    req.user = null;
    res.locals.user = null;
    return next();
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // { id, username, role }
    res.locals.user = decoded;
  } catch (err) {
    // Invalid / expired token — treat as logged out
    req.user = null;
    res.locals.user = null;
    res.clearCookie("token");
  }

  next();
};

/**
 * requireAuth
 * Blocks the request unless a valid user is attached by verifyToken.
 * Redirects to /login for normal page requests.
 */
const requireAuth = (req, res, next) => {
  if (!req.user) {
    return res.redirect("/login");
  }
  next();
};

/**
 * requireRole(...roles)
 * Blocks the request unless req.user.role is one of the allowed roles.
 * Example: requireRole("admin")
 */
const requireRole = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.redirect("/login");
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).render("error", {
        title: "Access Denied",
        message: "You do not have permission to view this page.",
      });
    }
    next();
  };
};

module.exports = { verifyToken, requireAuth, requireRole };
