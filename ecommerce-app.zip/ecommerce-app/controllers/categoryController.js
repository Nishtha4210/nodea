const Category = require("../models/Category");
const Product = require("../models/Product");

// GET /categories — list all categories (any logged-in user)
exports.listCategories = async (req, res) => {
  const categories = await Category.find().sort({ name: 1 });
  res.render("categoryList", { title: "Categories", categories });
};

// GET /categories/new — show create-category form (admin only)
exports.newCategoryForm = (req, res) => {
  res.render("categoryForm", {
    title: "Add Category",
    category: null,
    error: null,
  });
};

// POST /categories — create category (admin only)
exports.createCategory = async (req, res) => {
  try {
    const { name, description } = req.body;
    await Category.create({ name, description });
    res.redirect("/categories");
  } catch (err) {
    res.status(400).render("categoryForm", {
      title: "Add Category",
      category: null,
      error: "Could not create category. Name may already exist.",
    });
  }
};

// GET /categories/:id/edit — show edit form (admin only)
exports.editCategoryForm = async (req, res) => {
  const category = await Category.findById(req.params.id);
  if (!category) return res.redirect("/categories");
  res.render("categoryForm", { title: "Edit Category", category, error: null });
};

// PUT /categories/:id — update category (admin only)
exports.updateCategory = async (req, res) => {
  try {
    const { name, description } = req.body;
    await Category.findByIdAndUpdate(req.params.id, { name, description });
    res.redirect("/categories");
  } catch (err) {
    res.status(400).render("categoryForm", {
      title: "Edit Category",
      category: { _id: req.params.id, ...req.body },
      error: "Could not update category.",
    });
  }
};

// DELETE /categories/:id — delete category (admin only)
exports.deleteCategory = async (req, res) => {
  // Prevent deleting a category that still has products attached to it
  const productCount = await Product.countDocuments({ category: req.params.id });
  if (productCount > 0) {
    const categories = await Category.find().sort({ name: 1 });
    return res.status(400).render("categoryList", {
      title: "Categories",
      categories,
      error: `Cannot delete — ${productCount} product(s) still use this category.`,
    });
  }
  await Category.findByIdAndDelete(req.params.id);
  res.redirect("/categories");
};
