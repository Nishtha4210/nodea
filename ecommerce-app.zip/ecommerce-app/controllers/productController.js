const Product = require("../models/Product");
const Category = require("../models/Category");
const User = require("../models/User");

// GET /products — all products from all users, with optional ?category= filter
// .populate() pulls in the actual category name and owner username instead
// of just showing raw ObjectIds.
exports.listAllProducts = async (req, res) => {
  const { category } = req.query;
  const filter = category ? { category } : {};

  const [products, categories] = await Promise.all([
    Product.find(filter).populate("category").populate("user", "username").sort({ createdAt: -1 }),
    Category.find().sort({ name: 1 }),
  ]);

  res.render("productList", {
    title: "All Products",
    products,
    categories,
    selectedCategory: category || "",
  });
};

// GET /products/mine — only products created by the logged-in user
exports.listMyProducts = async (req, res) => {
  const products = await Product.find({ user: req.user.id })
    .populate("category")
    .populate("user", "username")
    .sort({ createdAt: -1 });

  res.render("myProducts", { title: "My Products", products });
};

// GET /products/:id — single product detail view
exports.getProduct = async (req, res) => {
  const product = await Product.findById(req.params.id)
    .populate("category")
    .populate("user", "username");

  if (!product) {
    return res.status(404).render("error", {
      title: "Not Found",
      message: "Product not found.",
    });
  }

  res.render("productItem", { title: product.name, product });
};

// GET /products/new — show create-product form
exports.newProductForm = async (req, res) => {
  const categories = await Category.find().sort({ name: 1 });
  res.render("productForm", {
    title: "Add Product",
    product: null,
    categories,
    error: null,
  });
};

// POST /products — create a product owned by the logged-in user
exports.createProduct = async (req, res) => {
  try {
    const { name, description, price, image, stock, category } = req.body;

    const product = await Product.create({
      name,
      description,
      price,
      image: image || undefined,
      stock: stock || 0,
      category,
      user: req.user.id,
    });

    // Multi-user support: keep the User document's product list in sync
    await User.findByIdAndUpdate(req.user.id, { $push: { products: product._id } });

    res.redirect("/products/mine");
  } catch (err) {
    console.error(err);
    const categories = await Category.find().sort({ name: 1 });
    res.status(400).render("productForm", {
      title: "Add Product",
      product: null,
      categories,
      error: "Could not create product. Check the fields and try again.",
    });
  }
};

// GET /products/:id/edit — show edit form (owner or admin only)
exports.editProductForm = async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product) return res.redirect("/products");

  const isOwner = product.user.toString() === req.user.id;
  if (!isOwner && req.user.role !== "admin") {
    return res.status(403).render("error", {
      title: "Access Denied",
      message: "You can only edit your own products.",
    });
  }

  const categories = await Category.find().sort({ name: 1 });
  res.render("productForm", { title: "Edit Product", product, categories, error: null });
};

// PUT /products/:id — update a product (owner or admin only)
exports.updateProduct = async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product) return res.redirect("/products");

  const isOwner = product.user.toString() === req.user.id;
  if (!isOwner && req.user.role !== "admin") {
    return res.status(403).render("error", {
      title: "Access Denied",
      message: "You can only edit your own products.",
    });
  }

  try {
    const { name, description, price, image, stock, category } = req.body;
    product.set({ name, description, price, image, stock, category });
    await product.save();
    res.redirect("/products/mine");
  } catch (err) {
    const categories = await Category.find().sort({ name: 1 });
    res.status(400).render("productForm", {
      title: "Edit Product",
      product,
      categories,
      error: "Could not update product.",
    });
  }
};

// DELETE /products/:id — delete a product (owner or admin only)
exports.deleteProduct = async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product) return res.redirect("/products");

  const isOwner = product.user.toString() === req.user.id;
  if (!isOwner && req.user.role !== "admin") {
    return res.status(403).render("error", {
      title: "Access Denied",
      message: "You can only delete your own products.",
    });
  }

  await Product.findByIdAndDelete(req.params.id);
  await User.findByIdAndUpdate(product.user, { $pull: { products: product._id } });

  res.redirect("/products/mine");
};
